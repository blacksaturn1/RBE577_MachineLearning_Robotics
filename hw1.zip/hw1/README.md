# RBE577_MachineLearning_Robotics

## Implemented the algorithms and data  studied in the paper "Constrained control allocation for dynamic ship positioning using deep neural network"

## Setup
* Setup a venv environment with Python 3.10.12
* Run: pip install -r requirements.txt

## Running Traininig
Run main.py

